package com.example.demo.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "USER")
@Data
public class User implements Serializable {
	@Id
	@Column(name = "MOB_NUM")
	private long phoneNumber;
	@Column(name = "NAME")
	private String name;
	@Column(name = "PASSWORD")
	private String password;
	@Column(name = "EMAIL")
	private String email;
	@Embedded
	private Address address;
	@OneToOne(cascade = CascadeType.ALL)  	//working
//	@JoinColumn(name = "cart_id", referencedColumnName = "cartId")
	private Cart cart;

}
