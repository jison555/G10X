package com.example.demo.service;

import com.example.demo.entity.Location;

public interface LocationService {
	
	public Location addLocation(Location loc);

}
