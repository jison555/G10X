package com.example.demo.exception;

public class NoDataFoundException extends Exception{
	
	private static final long serialVersionUID = 00100100100L;

}
