package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Category;
import com.example.demo.entity.Product;
import com.example.demo.exception.NoDataFoundException;
import com.example.demo.model.ProductModel;
import com.example.demo.repository.CategoryRepo;
import com.example.demo.repository.ProductRepository;
import com.example.demo.util.ProductModelMapper;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	CategoryRepo catRepo;

	@Autowired
	ProductModelMapper modelMapperUtil;

	@Override
	public List<ProductModel> getAllProducts() {
		List<Product> allProducts = productRepo.findAll();
		return allProducts.stream().map(modelMapperUtil::convertProductToModel).collect(Collectors.toList());
	}

	@Override
	public ProductModel saveProduct(ProductModel prodModel) {
		Product product = modelMapperUtil.convertProductToEntity(prodModel);
		int id =  product.getCategory().getCategoryId();
		Optional<Category> optCat =  catRepo.findById(id);
		if(optCat.isPresent()) {
			product.setCategory(optCat.get());
		}
		product = productRepo.save(product);
		return modelMapperUtil.convertProductToModel(product);
	}

	@Override
	public ProductModel getProductById(int id) throws NoDataFoundException {
		Optional<Product> prod = productRepo.findById(id);
		if (prod.isPresent()) {
			return modelMapperUtil.convertProductToModel(prod.get());
		} else {
			throw new NoDataFoundException();
		}
	}

	@Override
	public List<ProductModel> updateQuantityOfProduct(List<ProductModel> listProdModel) {
		// TODO Auto-generated method stub
		List<Product> products = listProdModel.stream().map(modelMapperUtil::convertProductToEntity)
				.collect(Collectors.toList());
		List<ProductModel> updatedProducts = new ArrayList<>();

		List<Product> productsData = products.stream().map(prod -> prod.getProdId()).map(productRepo::findById)
				.filter(x -> x.isPresent()).map(x -> x.get()).collect(Collectors.toList());

		for (Product prod : products) {
			for (Product prod1 : productsData) {
				if (prod.getProdId() == prod1.getProdId() && (prod1.getStockLevel()>=prod.getStockLevel())) {
					prod1.setStockLevel((prod1.getStockLevel() - prod.getStockLevel()));
					Product product =  productRepo.save(prod1);
					product.setStockLevel(prod.getStockLevel());
					updatedProducts.add(modelMapperUtil.convertProductToModel(product));
					break;
				}
			}
		}

		return updatedProducts;

	}

	@Override
	public int saveProductByLocId(Product prod, int locid) {
		// return productRepo.insertDataByprodId(prod,locid);
		return 1;
	}

	@Override
	public ProductModel updateProduct(ProductModel prodModel, int id) throws NoDataFoundException {

		Optional<Product> optionalProduct = productRepo.findById(id);
		if (optionalProduct.isPresent()) {
			Product product = modelMapperUtil.convertProductToEntity(prodModel);
			product.setProdId(optionalProduct.get().getProdId());
			product = productRepo.save(product);
			return modelMapperUtil.convertProductToModel(product);
		} else {
			throw new NoDataFoundException();
		}
	}

	@Override
	public void deleteProduct(int id) throws NoDataFoundException {
		try {
			productRepo.deleteById(id);
		} catch (Exception e) {
			throw new NoDataFoundException();
		}
	}

}
